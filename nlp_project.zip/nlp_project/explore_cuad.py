import json

# Load the CUAD dataset
with open(r"C:\Users\ranja\OneDrive\Desktop\nlp_project\Datasets\test.json", "r", encoding="utf-8") as file:
    data = json.load(file)

# Print dataset keys
print("Dataset Keys:", data.keys())

# Check if 'data' key exists
if "data" in data:
    print("\nFirst 2 Entries in 'data':")
    print(json.dumps(data["data"][:2], indent=4))  # Print first 2 contract entries
else:
    print("\nNo 'data' key found in the JSON file.")
