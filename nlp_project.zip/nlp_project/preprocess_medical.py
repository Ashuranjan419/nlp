import pandas as pd
import os

# Load the dataset
file_path = r"C:\Users\ranja\OneDrive\Desktop\nlp_project\Datasets\medicalmalpractice.csv"  
df = pd.read_csv(file_path)

# Display basic info
print("Initial dataset shape:", df.shape)
print("Columns:", df.columns)

# Handle missing values (fill/drop as needed)
df = df.dropna()  # Drop rows with missing values (adjust based on analysis)

# Standardize column names (remove spaces, lowercase)
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Convert categorical columns to lowercase
for col in df.select_dtypes(include=["object"]).columns:
    df[col] = df[col].str.lower().str.strip()

# Ensure 'data' folder exists
os.makedirs("data", exist_ok=True)

# Save the cleaned dataset
output_path = "data/medical_malpractice_cleaned.csv"
df.to_csv(output_path, index=False)

print(f"Cleaned dataset saved at: {output_path}")
