import json
import os

# Load the dataset
dataset_path = r"C:\Users\ranja\OneDrive\Desktop\nlp_project\Datasets\test.json"
output_path = r"C:\Users\ranja\OneDrive\Desktop\nlp_project\data\extracted_contracts.json"

# Ensure the output directory exists
os.makedirs(os.path.dirname(output_path), exist_ok=True)

def extract_contracts(data):
    extracted_contracts = []

    for contract in data.get("data", []):  # Extract from 'data' key
        contract_title = contract.get("title", "Unknown Contract")
        contract_text = contract.get("text", "")  # Extract full contract text
        clauses = contract.get("annotations", [])  # Extract legal clauses

        extracted_contracts.append({
            "title": contract_title,
            "text": contract_text,
            "clauses": clauses
        })

    return extracted_contracts

# Load and extract contracts
with open(dataset_path, "r", encoding="utf-8") as file:
    data = json.load(file)

contracts = extract_contracts(data)

# Save extracted data for further processing
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(contracts, f, indent=4)

print(f" Extracted {len(contracts)} contracts and saved them to {output_path}")
