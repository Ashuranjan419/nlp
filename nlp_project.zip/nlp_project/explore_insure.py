from datasets import load_dataset
import os

# Define the save path
data_folder = "data"
os.makedirs(data_folder, exist_ok=True)  # Ensure the folder exists

# Load the dataset
dataset = load_dataset("deccan-ai/insuranceQA-v2")

# Save dataset as JSON in the 'data' folder
dataset_path = os.path.join(data_folder, "insuranceQA.json")
dataset.save_to_disk(dataset_path)

print(f"Dataset saved at: {dataset_path}")
