import json
import os
import spacy
import string
from spacy.lang.en.stop_words import STOP_WORDS

# Load the extracted contracts
input_path = r"C:\Users\ranja\OneDrive\Desktop\nlp_project\data\extracted_contracts.json"
output_path = r"C:\Users\ranja\OneDrive\Desktop\nlp_project\data\preprocessed_contracts.json"

# Ensure the output directory exists
os.makedirs(os.path.dirname(output_path), exist_ok=True)

# Load spaCy's English model
nlp = spacy.load("en_core_web_sm")

def preprocess_text(text):
    """
    Function to clean and preprocess contract text.
    """
    # Convert text to lowercase
    text = text.lower()

    # Remove punctuation and special characters
    text = text.translate(str.maketrans("", "", string.punctuation))

    # Process text with spaCy
    doc = nlp(text)

    # Remove stopwords & perform lemmatization
    cleaned_tokens = [token.lemma_ for token in doc if token.text not in STOP_WORDS and not token.is_space]

    # Join tokens back into a string
    return " ".join(cleaned_tokens)

# Load extracted contract data
with open(input_path, "r", encoding="utf-8") as file:
    contracts = json.load(file)

# Apply preprocessing to each contract
for contract in contracts:
    contract["cleaned_text"] = preprocess_text(contract["text"])  # Add cleaned text

# Save preprocessed contracts
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(contracts, f, indent=4)

print(f"Preprocessed {len(contracts)} contracts and saved them to {output_path}")
